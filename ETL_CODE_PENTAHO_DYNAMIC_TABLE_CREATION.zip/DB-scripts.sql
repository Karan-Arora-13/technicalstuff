CREATE TABLE `tbl_metadata_store` (
  `column_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `col_len` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE  PROCEDURE `USP_VIEW_DYNAMIC_TABLE_CREATION`(OUT retmsg VARCHAR(200) )
begin
declare lv_sqlst  text;
declare lv_table_name text DEFAULT 'tbl_1';

drop table if exists tbl_1;

set lv_sqlst=(select group_concat(concat(column_name,' ',data_type,'(',case when data_type='decimal' then concat(col_len,',0)') else concat(col_len,')') end ) order by column_name) from tbl_metadata_store group by '1');

SET @statmt =concat('create table ',lv_table_name,'(',lv_sqlst,')');

		PREPARE STMT FROM @statmt;
		EXECUTE STMT;
		DEALLOCATE PREPARE STMT;
end